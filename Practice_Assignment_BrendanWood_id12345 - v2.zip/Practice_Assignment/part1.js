// YCIT023 Practice Assignment - Part 1
// By Brendan Wood, ID 123456

console.log("Hello World");