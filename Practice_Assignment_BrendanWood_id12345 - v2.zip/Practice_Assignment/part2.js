// YCIT023 Practice Assignment - Part 1
// By Brendan Wood, ID 123456

let result = 1 + 1

console.log(result);
